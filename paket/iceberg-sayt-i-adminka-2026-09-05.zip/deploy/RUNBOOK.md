# RUNBOOK — переезд iceberg.spb.ru на новый статический сайт (sprinthost)

> Пошаговый безопасный переезд: смена движка WordPress → статика **без смены URL**
> (склейка). Ничего не удаляем без бэкапа; переключаемся только после сверки.
> Контекст и решения — [../../../seo.md](../../../seo.md). Сборка — [../../web_development.md](../../web_development.md).

---

## 0. Предусловия (собрать до старта)

- [ ] **Доступ к sprinthost** — SSH (лучше) или FTP + доступ к БД. SSH-ключ уже сгенерён
      (`~/.ssh/sprinthost_iceberg`), публичную часть добавить в панель.
- [ ] **OAuth-токен Яндекса** (Метрика 61680454 + Вебмастер iceberg.spb.ru) — для baseline.
- [ ] Понять веб-сервер: shared sprinthost — это **Apache**, редиректы берём из `.htaccess`
      (не `nginx-iceberg.conf`; nginx-версия — если дадут VPS/полный конфиг).

---

## 1. Baseline (ОБЯЗАТЕЛЬНО до любых изменений)

Снять точку отсчёта, чтобы после переезда сравнить «до/после»:
- Метрика: визиты/источники по каждому URL за 90–365 дней.
- Вебмастер: показы, клики, средняя позиция по топ-запросам и по URL.
- **Отдельно — трафик на `/trikotazhnie-polotna-pricelist1/`**: от него зависит решение
  301-на-biflex vs оставить снимок. Записать в `01-iceberg/tochka-otscheta-seo-v1.html`.

## 2. Полный бэкап WordPress (страховка отката)

По SSH:
```
mysqldump -u USER -p БАЗА | gzip > ~/wp-backup-$(date +%F).sql.gz
tar czf ~/wp-files-$(date +%F).tar.gz -C ~/ public_html
```
Скачать обе копии на Мак. **До этого шага сайт не трогаем.**

## 3. Релиз — уже собран, пересобирать НЕЧЕГО

> ⚠️⚠️ **НЕ запускать `build_v3.py` / `build_pages.py` / `build_release.py`.**
> С 4 сент 2026 сайт — это `04-site-iceberg/dist/` (сборка подрядчика, принята пользователем).
> Скрипты сгенерируют нашу версию от 19 августа и **затрут её**. Сборка уже боевая:
> гейт снят, `index, follow`, `robots.txt` — `Allow: /`.

Что проверить перед заливкой:
```
python3 tools/cms_markers.py --check     # метки админки на месте («уже размечена»)
cd 04-site-iceberg/backend && ./tests/stand.sh && python3 tests/smoke.py    # прогон админки на стенде
```

## 4. Сверка склейки ДО переключения

```
cd 04-site-iceberg/backend
php bin/check_seo.php --live https://iceberg.spb.ru
```
Сравнивает постранично `title` / `description` / `canonical` / `H1` с живым сайтом.
**`title` и `canonical` обязаны совпадать 1-в-1** (проверено 5 сент — совпадают на всех 9 адресах).
Отдельно, выборочно: каталог трикотажа — 301 на biflex; мусор/WP — 410.

## 5. Переключение (cutover)

- Забэкапленный WordPress убрать из `public_html` (переименовать, не удалять).
- Залить содержимое `dist/` в `public_html` (rsync/FTP).
- **Поверх** положить файлы из `04-site-iceberg/backend/public/`: `index.php`, `admin/`, `uploads/`
  и **объединённый `.htaccess`** (он перекрывает тот, что пришёл из `dist/` — так и надо).
- `app/` и `data/` разложить **выше** веб-корня, заполнить `app/config.php`.
- Поднять слой админки:
```
php bin/install_layout.php     # 11 страниц уезжают из public_html в baseline
php bin/create_admin.php
php bin/seed.php
php bin/check_deploy.php       # строк «!!!!» остаться не должно
```
- Проверить, что открываются все 11 адресов и работают редиректы.

## 6. После переключения

- [ ] `php bin/check_seo.php --live https://iceberg.spb.ru` — расхождений 0 (сравнение с самим собой).
- [ ] В Вебмастере залить новый `sitemap.xml`, старые `page-/post-sitemap.xml` уже 301-ятся.
- [ ] Проверить `robots.txt` (Allow, без Disallow: /), `noindex` снят.
- [ ] `/leads.log`, `/mail-config.php`, `/app/`, `/data/` из браузера дают **403**.
- [ ] `/admin/` открывается, вход + 2FA работают.
- [ ] Формы: отправить тестовую заявку — письмо пришло и заявка видна в админке.
      (SMTP в `dist/mail-config.php` должен быть заполнен, иначе письма не уйдут.)
- [ ] Прогнать сверку редиректов по `redirect-map-trikotazh.csv` (выборочно).
- [ ] Удалить с сервера `bin/check_env.php` и `bin/check_deploy.php`.

## 7. Мониторинг 2–4 недели

Сравнивать с baseline: позиции, показы, органика, ошибки в Вебмастере, конверсии заявок.
Отдельно смотреть `/shveinoe-proizvodstvo/` — единственная страница с изменённым H1
(«Швейное производство» → «Швейное производство одежды в Санкт-Петербурге»).
При заметной просадке — **откат по бэкапу** (вернуть WP из шага 2).

---

## Манифест web-root (что в `dist/`)

```
index.html                     — главная
hero-assets/seq-wide/          — кадры первого экрана
hero-assets/seq-full-fix/      — кадры блока «яхта»
tkani-optom/  contacts/  vacancy/  shveinoe-proizvodstvo/
izgotovlenie-kupalnikov-i-sportivnoi-odezhdi/  izgotovlenie-startovykh-maek/
mashinnaya-vishivka/  tkani-print/           — новый дизайн
emdi/  technicheskie-tkani/  trikotazhnie-polotna-pricelist1/  — снимки WP 1-в-1
_wp/                           — ассеты снимков (снимки ссылаются на ../_wp/ → /_wp/)
robots.txt  sitemap.xml  og-cover.jpg  .htaccess
```

## Проверка склейки (пример)

```
for u in "" tkani-optom/ contacts/ shveinoe-proizvodstvo/ ; do
  curl -s -o /dev/null -w "%{http_code} %{url_effective}\n" "https://iceberg.spb.ru/$u"
done
# каталог должен давать 301 на biflex:
curl -sI "https://iceberg.spb.ru/trikotazhnie-polotna/123/" | grep -i location
```

## Открытые решения перед боем
- **Прайс** `/trikotazhnie-polotna-pricelist1/`: оставить снимок или 301 на biflex — по baseline-трафику.
- **Снимки** emdi/technicheskie-tkani: пока 1-в-1 (безопасно для склейки), редизайн — в задачах EMDI/Tech.
- **Формы → CRM**: сейчас заглушка + `lead_submit` в dataLayer.
